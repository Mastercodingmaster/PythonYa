main = 1
print("Hello")
sso = print(main)
